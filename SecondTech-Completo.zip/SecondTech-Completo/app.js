const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");

const app = express();

// Rutas
const indexRoutes = require("./routes/index");
const anunciosRoutes = require("./routes/anuncios");

// Configuración EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.urlencoded({ extended: true }));

// Rutas
app.use(indexRoutes);
app.use("/anuncios", anunciosRoutes);

// Página 404
app.use((req, res, next) => {
  res.status(404).render("error_404", {
    pageTitle: "Página no encontrada"
  });
});

// Servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});

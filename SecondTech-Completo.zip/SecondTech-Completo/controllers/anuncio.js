const fs = require("fs");
const path = require("path");

const anunciosPath = path.join(__dirname, "..", "data", "anuncios.json");

// Leer anuncios desde el archivo JSON
const getAnuncios = () => {
  try {
    const data = fs.readFileSync(anunciosPath, "utf8");
    return JSON.parse(data);
  } catch (error) {
    console.error("Error al leer anuncios:", error);
    return [];
  }
};

// Guardar anuncios en el archivo JSON
const saveAnuncios = (anuncios) => {
  try {
    fs.writeFileSync(anunciosPath, JSON.stringify(anuncios, null, 2), "utf8");
    return true;
  } catch (error) {
    console.error("Error al guardar anuncios:", error);
    return false;
  }
};

// Obtener un anuncio por ID
const getAnuncioById = (id) => {
  const anuncios = getAnuncios();
  return anuncios.find((anuncio) => anuncio.id === id);
};

// Listar todos los anuncios con filtros opcionales
exports.getListado = (req, res) => {
  const { categoria, estado } = req.query;
  let anuncios = getAnuncios();

  // Aplicar filtro por categoría
  if (categoria && categoria !== "todas") {
    anuncios = anuncios.filter((a) => a.categoria === categoria);
  }

  // Aplicar filtro por estado
  if (estado && estado !== "todos") {
    anuncios = anuncios.filter((a) => a.estado === estado);
  }

  res.render("listado_anuncios", {
    pageTitle: "Listado de Anuncios",
    anuncios: anuncios,
    categoriaSeleccionada: categoria || "todas",
    estadoSeleccionado: estado || "todos"
  });
};

// Mostrar formulario de creación
exports.getNuevoAnuncio = (req, res) => {
  res.render("añadir_anuncio", {
    pageTitle: "Publicar Anuncio",
    errors: []
  });
};

// Crear un nuevo anuncio
exports.postNuevoAnuncio = (req, res) => {
  const { titulo, descripcion, categoria, precio, contacto } = req.body;
  const errors = [];

  // Validaciones
  if (!titulo || titulo.trim() === "") {
    errors.push("El título es obligatorio");
  }
  if (!descripcion || descripcion.trim() === "") {
    errors.push("La descripción es obligatoria");
  }
  if (!categoria) {
    errors.push("Debes seleccionar una categoría");
  }
  if (!precio || isNaN(precio) || precio <= 0) {
    errors.push("El precio debe ser un número mayor a 0");
  }
  if (!contacto || contacto.trim() === "") {
    errors.push("El contacto es obligatorio");
  }

  if (errors.length > 0) {
    return res.render("añadir_anuncio", {
      pageTitle: "Publicar Anuncio",
      errors: errors
    });
  }

  const anuncios = getAnuncios();
  const nuevoAnuncio = {
    id: Date.now().toString(),
    titulo: titulo.trim(),
    descripcion: descripcion.trim(),
    categoria: categoria,
    precio: parseFloat(precio),
    contacto: contacto.trim(),
    estado: "disponible",
    createdAt: new Date().toISOString().split("T")[0]
  };

  anuncios.push(nuevoAnuncio);
  saveAnuncios(anuncios);

  res.redirect("/anuncios");
};

// Mostrar detalle de un anuncio
exports.getDetalle = (req, res) => {
  const { id } = req.params;
  const anuncio = getAnuncioById(id);

  if (!anuncio) {
    return res.status(404).render("error_404", {
      pageTitle: "Anuncio no encontrado"
    });
  }

  res.render("detalle_anuncio", {
    pageTitle: anuncio.titulo,
    anuncio: anuncio
  });
};

// Mostrar formulario de edición
exports.getEditarAnuncio = (req, res) => {
  const { id } = req.params;
  const anuncio = getAnuncioById(id);

  if (!anuncio) {
    return res.status(404).render("error_404", {
      pageTitle: "Anuncio no encontrado"
    });
  }

  res.render("editar_anuncio", {
    pageTitle: "Editar Anuncio",
    anuncio: anuncio,
    errors: []
  });
};

// Actualizar un anuncio
exports.postEditarAnuncio = (req, res) => {
  const { id } = req.params;
  const { descripcion, precio, estado } = req.body;
  const errors = [];

  // Validaciones
  if (!descripcion || descripcion.trim() === "") {
    errors.push("La descripción es obligatoria");
  }
  if (!precio || isNaN(precio) || precio <= 0) {
    errors.push("El precio debe ser un número mayor a 0");
  }

  const anuncio = getAnuncioById(id);
  if (!anuncio) {
    return res.status(404).render("error_404", {
      pageTitle: "Anuncio no encontrado"
    });
  }

  if (errors.length > 0) {
    return res.render("editar_anuncio", {
      pageTitle: "Editar Anuncio",
      anuncio: anuncio,
      errors: errors
    });
  }

  const anuncios = getAnuncios();
  const index = anuncios.findIndex((a) => a.id === id);

  if (index !== -1) {
    anuncios[index].descripcion = descripcion.trim();
    anuncios[index].precio = parseFloat(precio);
    anuncios[index].estado = estado;
    saveAnuncios(anuncios);
  }

  res.redirect(`/anuncios/${id}`);
};

// Cambiar estado de un anuncio
exports.postCambiarEstado = (req, res) => {
  const { id } = req.params;
  const { estado } = req.body;

  const anuncios = getAnuncios();
  const index = anuncios.findIndex((a) => a.id === id);

  if (index !== -1) {
    anuncios[index].estado = estado;
    saveAnuncios(anuncios);
  }

  res.redirect(`/anuncios/${id}`);
};

const express = require("express");
const router = express.Router();
const anuncioController = require("../controllers/anuncio");

// Listado de anuncios con filtros
router.get("/", anuncioController.getListado);

// Formulario para nuevo anuncio
router.get("/nuevo", anuncioController.getNuevoAnuncio);

// Crear nuevo anuncio
router.post("/", anuncioController.postNuevoAnuncio);

// Detalle de un anuncio
router.get("/:id", anuncioController.getDetalle);

// Formulario de edición
router.get("/:id/editar", anuncioController.getEditarAnuncio);

// Actualizar anuncio
router.post("/:id", anuncioController.postEditarAnuncio);

// Cambiar estado
router.post("/:id/estado", anuncioController.postCambiarEstado);

module.exports = router;

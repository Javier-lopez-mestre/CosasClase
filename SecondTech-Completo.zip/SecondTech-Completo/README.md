# SecondTech - Plataforma de Compraventa de Tecnología

Plataforma web de compraventa de tecnología de segunda mano, similar a Wallapop. Desarrollada con Node.js y Express.

## 📋 Descripción

SecondTech es una aplicación web que permite a los usuarios publicar, consultar y gestionar anuncios de productos tecnológicos como móviles, consolas, ordenadores y componentes.

## 🚀 Características

- ✅ Listado de anuncios con filtros por categoría y estado
- ✅ Publicación de nuevos anuncios
- ✅ Visualización detallada de anuncios
- ✅ Edición de anuncios existentes
- ✅ Cambio de estado (disponible, reservado, vendido)
- ✅ Persistencia de datos en JSON
- ✅ Interfaz responsive y moderna
- ✅ Validación de formularios
- ✅ Página 404 personalizada

## 🛠️ Tecnologías Utilizadas

- **Node.js** - Entorno de ejecución
- **Express.js** - Framework web
- **EJS** - Motor de plantillas
- **body-parser** - Procesamiento de formularios
- **CSS3** - Estilos personalizados

## 📦 Instalación

1. Clonar el repositorio
```bash
git clone https://github.com/Javier-lopez-mestre/SecondTech---Hector-Javier.git
cd SecondTech---Hector-Javier
```

2. Instalar dependencias
```bash
npm install
```

3. Iniciar el servidor
```bash
npm start
```

O para desarrollo con reinicio automático:
```bash
npm run dev
```

4. Abrir en el navegador
```
http://localhost:3000
```

## 📁 Estructura del Proyecto

```
SecondTech/
├── app.js                 # Archivo principal
├── package.json           # Dependencias
├── controllers/
│   └── anuncio.js        # Lógica de negocio
├── routes/
│   ├── index.js          # Rutas página principal
│   └── anuncios.js       # Rutas de anuncios
├── views/
│   ├── index.ejs         # Página principal
│   ├── listado_anuncios.ejs
│   ├── añadir_anuncio.ejs
│   ├── detalle_anuncio.ejs
│   ├── editar_anuncio.ejs
│   ├── error_404.ejs
│   └── includes/
│       ├── header.ejs
│       ├── navigation.ejs
│       └── footer.ejs
├── data/
│   └── anuncios.json     # Base de datos JSON
└── public/
    ├── css/
    │   └── styles.css
    └── images/
        └── logo.png
```

## 🌐 Rutas Principales

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/` | Página principal |
| GET | `/anuncios` | Listado de anuncios (con filtros) |
| GET | `/anuncios/nuevo` | Formulario nuevo anuncio |
| POST | `/anuncios` | Crear anuncio |
| GET | `/anuncios/:id` | Detalle de anuncio |
| GET | `/anuncios/:id/editar` | Formulario edición |
| POST | `/anuncios/:id` | Actualizar anuncio |
| POST | `/anuncios/:id/estado` | Cambiar estado |

## 💾 Estructura de Datos

Cada anuncio contiene:
```json
{
  "id": "1736851200000",
  "titulo": "iPhone 13 Pro 128GB",
  "descripcion": "En perfecto estado...",
  "categoria": "movil",
  "precio": 550,
  "contacto": "usuario@email.com",
  "estado": "disponible",
  "createdAt": "2026-01-14"
}
```

**Categorías disponibles:**
- movil
- consola
- pc
- componentes
- otros

**Estados disponibles:**
- disponible
- reservado
- vendido

## 👥 Autores

- Héctor
- Javier

**Curso:** Ciclo Formativo de Grado Superior - Informática  
**Módulo:** AWS2 - Módulo DUAL

## 📄 Licencia

ISC

## 🐛 Contribuir

Este es un proyecto educativo. Para reportar problemas o sugerencias, abre un issue en el repositorio.

